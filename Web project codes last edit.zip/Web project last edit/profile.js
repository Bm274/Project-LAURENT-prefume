const profileForm =
document.getElementById("profileForm");

const fullName =
document.getElementById("fullName");

const email =
document.getElementById("email");

const phone =
document.getElementById("phone");

const locationInput =
document.getElementById("location");

const address =
document.getElementById("address");

function validate(input, errorId, message){

  const error =
  document.getElementById(errorId);

  if(input.value.trim() === ""){

    error.textContent = message;

    input.classList.add("error");
    input.classList.remove("success");

    return false;

  } else {

    error.textContent = "";

    input.classList.remove("error");
    input.classList.add("success");

    return true;
  }
}
function logout() {

    localStorage.setItem("isLoggedIn", "false");

    window.location.href = "signin.html";

}

function validateEmail(){

  const emailError =
  document.getElementById("emailError");

  if(email.value.trim() === ""){

    emailError.textContent =
    "Email is required";

    email.classList.add("error");

    return false;

  } else if(!email.value.includes("@")){

    emailError.textContent =
    "Example: nours1428@gmail.com";

    email.classList.add("error");

    return false;

  } else {

    emailError.textContent = "";

    email.classList.remove("error");
    email.classList.add("success");

    return true;
  }
}

function displaySavedData(){

  document.getElementById("savedName").textContent =
  localStorage.getItem("profileName") || "No data";

  document.getElementById("savedEmail").textContent =
  localStorage.getItem("profileEmail") || "No data";

  document.getElementById("savedPhone").textContent =
  localStorage.getItem("profilePhone") || "No data";

  document.getElementById("savedLocation").textContent =
  localStorage.getItem("profileLocation") || "No data";

  document.getElementById("savedAddress").textContent =
  localStorage.getItem("profileAddress") || "No data";

  document.getElementById("profileNamePreview").textContent =
  localStorage.getItem("profileName") || "Guest User";
}
profileForm.addEventListener("submit",
function(event){

  event.preventDefault();

  const validName =
  validate(fullName,
  "nameError",
  "Name is required");

  const validEmail =
  validateEmail();

  const validPhone =
  validate(phone,
  "phoneError",
  "Phone number is required"); const validLocation =
  validate(locationInput,
  "locationError",
  "Location is required");

  const validAddress =
  validate(address,
  "addressError",
  "Address is required");

  if(
    validName &&
    validEmail &&
    validPhone &&
    validLocation &&
    validAddress
  ){

  localStorage.setItem(
      "profileName",
      fullName.value
    );

    localStorage.setItem(
      "profileEmail",
      email.value
    );

    localStorage.setItem(
      "profilePhone",
      phone.value
    );

    localStorage.setItem(
      "profileLocation",
      locationInput.value
    );

    localStorage.setItem(
      "profileAddress",
      address.value
    );
     document.getElementById("successMessage")
    .textContent =
    "Profile saved successfully!";

    displaySavedData();
  }

});
displaySavedData();
